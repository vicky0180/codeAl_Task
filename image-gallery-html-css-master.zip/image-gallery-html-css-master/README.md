# image-gallery-html-css
HTML and  CSS (some JS) Image Gallery

Simple image gallery created with HTML, CSS and some JavaScript. 

## Features
1.  Responsive using Media Queries
2.  Hover using transitions and opacity
3.  Top navigation links to each section
4.  Scroll Top using simple JavaScript 

## View Project
Project can be viewed [here](https://jonesdl-2785.github.io/image-gallery-html-css/).
